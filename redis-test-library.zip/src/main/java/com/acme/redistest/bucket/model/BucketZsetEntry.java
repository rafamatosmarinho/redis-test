package com.acme.redistest.bucket.model;

public record BucketZsetEntry(String member, double score) {
}
