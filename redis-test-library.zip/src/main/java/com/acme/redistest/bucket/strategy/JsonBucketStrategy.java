package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.model.BucketValue;
import com.acme.redistest.connection.RedisOps;
import com.jayway.jsonpath.JsonPath;

public class JsonBucketStrategy implements BucketStrategy {

    private final RedisOps redisOps;

    public JsonBucketStrategy(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    @Override
    public BucketState read(String key, String jsonPath) {
        String json = redisOps.jsonGet(key);
        if (jsonPath == null || jsonPath.isBlank()) {
            return new BucketState(key, BucketValue.builder().jsonValue(json).build());
        }

        Object value = JsonPath.parse(json).read(jsonPath);
        String rawValue = value == null ? null : String.valueOf(value);
        Long numericValue = parseLong(rawValue);

        return new BucketState(key, BucketValue.builder()
                .jsonValue(json)
                .rawValue(rawValue)
                .numericValue(numericValue)
                .build());
    }

    private Long parseLong(String value) {
        if (value == null) return null;
        try {
            if (value.contains(".")) {
                return (long) Double.parseDouble(value);
            }
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
