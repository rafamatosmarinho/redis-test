package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.model.BucketValue;
import com.acme.redistest.connection.RedisOps;

import java.util.List;

public class ListBucketStrategy implements BucketStrategy {

    private final RedisOps redisOps;

    public ListBucketStrategy(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    @Override
    public BucketState read(String key, String locator) {
        List<String> value = redisOps.lrange(key, 0, -1);
        return new BucketState(key, BucketValue.builder().listValue(value).build());
    }
}
