package com.acme.redistest.bucket.model;

public class BucketState {

    private final String key;
    private final BucketValue value;

    public BucketState(String key, BucketValue value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public BucketValue getValue() {
        return value;
    }
}
