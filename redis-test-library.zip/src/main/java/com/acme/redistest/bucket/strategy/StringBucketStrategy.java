package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.model.BucketValue;
import com.acme.redistest.connection.RedisOps;

public class StringBucketStrategy implements BucketStrategy {

    private final RedisOps redisOps;

    public StringBucketStrategy(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    @Override
    public BucketState read(String key, String locator) {
        String value = redisOps.get(key);
        return new BucketState(key, BucketValue.builder()
                .rawValue(value)
                .numericValue(parseLong(value))
                .build());
    }

    private Long parseLong(String value) {
        if (value == null) return null;
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
