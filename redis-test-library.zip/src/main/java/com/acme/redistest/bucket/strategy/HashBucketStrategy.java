package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.model.BucketValue;
import com.acme.redistest.connection.RedisOps;

import java.util.Map;

public class HashBucketStrategy implements BucketStrategy {

    private final RedisOps redisOps;

    public HashBucketStrategy(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    @Override
    public BucketState read(String key, String field) {
        if (field == null || field.isBlank()) {
            Map<String, String> hash = redisOps.hgetAll(key);
            return new BucketState(key, BucketValue.builder().hashValue(hash).build());
        }
        String value = redisOps.hget(key, field);
        return new BucketState(key, BucketValue.builder()
                .rawValue(value)
                .numericValue(parseLong(value))
                .build());
    }

    private Long parseLong(String value) {
        if (value == null) return null;
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
