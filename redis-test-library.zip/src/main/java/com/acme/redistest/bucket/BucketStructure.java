package com.acme.redistest.bucket;

public enum BucketStructure {
    STRING,
    HASH,
    LIST,
    SET,
    ZSET,
    JSON
}
