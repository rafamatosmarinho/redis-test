package com.acme.redistest.bucket;

import com.acme.redistest.bucket.model.BucketConsumptionResult;
import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.strategy.BucketStrategy;
import com.acme.redistest.bucket.strategy.HashBucketStrategy;
import com.acme.redistest.bucket.strategy.JsonBucketStrategy;
import com.acme.redistest.bucket.strategy.ListBucketStrategy;
import com.acme.redistest.bucket.strategy.SetBucketStrategy;
import com.acme.redistest.bucket.strategy.StringBucketStrategy;
import com.acme.redistest.bucket.strategy.ZsetBucketStrategy;
import com.acme.redistest.connection.RedisOps;
import com.acme.redistest.core.RedisAwait;
import com.acme.redistest.exception.UnsupportedBucketStructureException;

import java.time.Duration;

public class BucketFacade {

    private final RedisOps redisOps;
    private final String key;
    private BucketStructure structure;
    private String locator;
    private Duration timeout = Duration.ofSeconds(2);
    private Duration interval = Duration.ofMillis(150);

    public BucketFacade(RedisOps redisOps, String key) {
        this.redisOps = redisOps;
        this.key = key;
    }

    public BucketFacade using(BucketStructure structure) {
        this.structure = structure;
        return this;
    }

    public BucketFacade field(String field) {
        this.locator = field;
        return this;
    }

    public BucketFacade jsonPath(String jsonPath) {
        this.locator = jsonPath;
        return this;
    }

    public BucketFacade await(Duration timeout, Duration interval) {
        this.timeout = timeout;
        this.interval = interval;
        return this;
    }

    public BucketState read() {
        return strategy().read(key, locator);
    }

    public BucketConsumptionResult verifyConsumption(long expectedConsumed, Runnable action) {
        BucketState before = read();
        action.run();

        BucketState after = RedisAwait.until(
                this::read,
                state -> state.getValue().getNumericValue() != null
                        && before.getValue().getNumericValue() != null
                        && state.getValue().getNumericValue().longValue()
                        == before.getValue().getNumericValue().longValue() - expectedConsumed,
                timeout,
                interval
        );

        return new BucketConsumptionResult(before, after);
    }

    private BucketStrategy strategy() {
        if (structure == null) {
            throw new IllegalStateException("Use using(BucketStructure) before reading a bucket");
        }

        return switch (structure) {
            case STRING -> new StringBucketStrategy(redisOps);
            case HASH -> new HashBucketStrategy(redisOps);
            case LIST -> new ListBucketStrategy(redisOps);
            case SET -> new SetBucketStrategy(redisOps);
            case ZSET -> new ZsetBucketStrategy(redisOps);
            case JSON -> new JsonBucketStrategy(redisOps);
            default -> throw new UnsupportedBucketStructureException("Unsupported structure: " + structure);
        };
    }
}
