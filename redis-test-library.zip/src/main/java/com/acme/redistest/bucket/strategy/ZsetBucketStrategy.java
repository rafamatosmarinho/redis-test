package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.model.BucketValue;
import com.acme.redistest.bucket.model.BucketZsetEntry;
import com.acme.redistest.connection.RedisOps;

import java.util.List;

public class ZsetBucketStrategy implements BucketStrategy {

    private final RedisOps redisOps;

    public ZsetBucketStrategy(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    @Override
    public BucketState read(String key, String locator) {
        List<BucketZsetEntry> entries = redisOps.zrangeWithScores(key, 0, -1).stream()
                .map(tuple -> new BucketZsetEntry(tuple.value(), tuple.score()))
                .toList();

        return new BucketState(key, BucketValue.builder().zsetValue(entries).build());
    }
}
