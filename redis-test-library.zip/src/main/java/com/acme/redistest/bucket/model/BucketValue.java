package com.acme.redistest.bucket.model;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class BucketValue {

    private final String rawValue;
    private final Long numericValue;
    private final Map<String, String> hashValue;
    private final List<String> listValue;
    private final Set<String> setValue;
    private final List<BucketZsetEntry> zsetValue;
    private final String jsonValue;

    private BucketValue(Builder builder) {
        this.rawValue = builder.rawValue;
        this.numericValue = builder.numericValue;
        this.hashValue = builder.hashValue;
        this.listValue = builder.listValue;
        this.setValue = builder.setValue;
        this.zsetValue = builder.zsetValue;
        this.jsonValue = builder.jsonValue;
    }

    public String getRawValue() { return rawValue; }
    public Long getNumericValue() { return numericValue; }
    public Map<String, String> getHashValue() { return hashValue; }
    public List<String> getListValue() { return listValue; }
    public Set<String> getSetValue() { return setValue; }
    public List<BucketZsetEntry> getZsetValue() { return zsetValue; }
    public String getJsonValue() { return jsonValue; }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private String rawValue;
        private Long numericValue;
        private Map<String, String> hashValue;
        private List<String> listValue;
        private Set<String> setValue;
        private List<BucketZsetEntry> zsetValue;
        private String jsonValue;

        public Builder rawValue(String rawValue) { this.rawValue = rawValue; return this; }
        public Builder numericValue(Long numericValue) { this.numericValue = numericValue; return this; }
        public Builder hashValue(Map<String, String> hashValue) { this.hashValue = hashValue; return this; }
        public Builder listValue(List<String> listValue) { this.listValue = listValue; return this; }
        public Builder setValue(Set<String> setValue) { this.setValue = setValue; return this; }
        public Builder zsetValue(List<BucketZsetEntry> zsetValue) { this.zsetValue = zsetValue; return this; }
        public Builder jsonValue(String jsonValue) { this.jsonValue = jsonValue; return this; }

        public BucketValue build() { return new BucketValue(this); }
    }
}
