package com.acme.redistest.bucket.model;

import org.testng.Assert;

public class BucketConsumptionResult {

    private final BucketState before;
    private final BucketState after;

    public BucketConsumptionResult(BucketState before, BucketState after) {
        this.before = before;
        this.after = after;
    }

    public BucketState getBefore() {
        return before;
    }

    public BucketState getAfter() {
        return after;
    }

    public void assertConsumedExactly(long amount) {
        Assert.assertNotNull(before.getValue().getNumericValue(), "Previous value is not numeric");
        Assert.assertNotNull(after.getValue().getNumericValue(), "Next value is not numeric");
        Assert.assertEquals(after.getValue().getNumericValue().longValue(),
                before.getValue().getNumericValue() - amount,
                "Unexpected bucket consumption");
    }

    public void assertRemainingEquals(long amount) {
        Assert.assertNotNull(after.getValue().getNumericValue(), "Next value is not numeric");
        Assert.assertEquals(after.getValue().getNumericValue().longValue(), amount, "Unexpected remaining amount");
    }
}
