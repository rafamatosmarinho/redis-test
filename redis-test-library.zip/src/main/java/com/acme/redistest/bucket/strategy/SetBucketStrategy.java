package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;
import com.acme.redistest.bucket.model.BucketValue;
import com.acme.redistest.connection.RedisOps;

public class SetBucketStrategy implements BucketStrategy {

    private final RedisOps redisOps;

    public SetBucketStrategy(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    @Override
    public BucketState read(String key, String locator) {
        return new BucketState(key, BucketValue.builder().setValue(redisOps.smembers(key)).build());
    }
}
