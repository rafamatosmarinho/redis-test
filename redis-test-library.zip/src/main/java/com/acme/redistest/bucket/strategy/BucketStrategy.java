package com.acme.redistest.bucket.strategy;

import com.acme.redistest.bucket.model.BucketState;

public interface BucketStrategy {
    BucketState read(String key, String locator);
}
