package com.acme.redistest.connection;

import redis.clients.jedis.Tuple;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public abstract class AbstractJedisOps implements RedisOps {

    protected List<TupleValue> mapTuples(Set<Tuple> tuples) {
        return tuples.stream()
                .map(tuple -> new TupleValue(tuple.getElement(), tuple.getScore()))
                .collect(Collectors.toList());
    }
}
