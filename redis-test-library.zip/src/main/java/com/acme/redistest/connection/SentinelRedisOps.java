package com.acme.redistest.connection;

import redis.clients.jedis.RedisSentinelClient;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SentinelRedisOps extends AbstractJedisOps {

    private final RedisSentinelClient client;

    public SentinelRedisOps(RedisSentinelClient client) {
        this.client = client;
    }

    @Override public String get(String key) { return client.get(key); }
    @Override public String set(String key, String value) { return client.set(key, value); }
    @Override public String hget(String key, String field) { return client.hget(key, field); }
    @Override public Map<String, String> hgetAll(String key) { return client.hgetAll(key); }
    @Override public Long hset(String key, String field, String value) { return client.hset(key, field, value); }
    @Override public Long hset(String key, Map<String, String> hash) { return client.hset(key, hash); }
    @Override public Long del(String key) { return client.del(key); }
    @Override public String type(String key) { return client.type(key); }
    @Override public Long ttl(String key) { return client.ttl(key); }
    @Override public Set<String> keys(String pattern) { return client.keys(pattern); }
    @Override public List<String> lrange(String key, long start, long stop) { return client.lrange(key, start, stop); }
    @Override public Set<String> smembers(String key) { return client.smembers(key); }
    @Override public List<TupleValue> zrangeWithScores(String key, long start, long stop) { return mapTuples(client.zrangeWithScores(key, start, stop)); }
    @Override public String jsonGet(String key) { return client.jsonGet(key); }
    @Override public void jsonSet(String key, String json) { client.jsonSet(key, json); }
    @Override public void close() { client.close(); }
}
