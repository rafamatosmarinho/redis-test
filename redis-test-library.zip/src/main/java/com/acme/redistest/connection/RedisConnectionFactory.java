package com.acme.redistest.connection;

import com.acme.redistest.config.RedisNode;
import com.acme.redistest.config.RedisTestConfig;
import redis.clients.jedis.DefaultJedisClientConfig;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisClientConfig;
import redis.clients.jedis.RedisClient;
import redis.clients.jedis.RedisClusterClient;
import redis.clients.jedis.RedisSentinelClient;

import java.util.Set;
import java.util.stream.Collectors;

public final class RedisConnectionFactory {

    private RedisConnectionFactory() {
    }

    public static RedisOps create(RedisTestConfig config) {
        JedisClientConfig clientConfig = DefaultJedisClientConfig.builder()
                .user(config.getUsername())
                .password(config.getPassword())
                .database(config.getDatabase())
                .ssl(config.isSsl())
                .timeoutMillis((int) config.getTimeout().toMillis())
                .socketTimeoutMillis((int) config.getSocketTimeout().toMillis())
                .build();

        return switch (config.getMode()) {
            case STANDALONE -> createStandalone(config, clientConfig);
            case CLUSTER -> createCluster(config, clientConfig);
            case SENTINEL -> createSentinel(config, clientConfig);
        };
    }

    private static RedisOps createStandalone(RedisTestConfig config, JedisClientConfig clientConfig) {
        RedisClient client = RedisClient.builder()
                .hostAndPort(config.getHost(), config.getPort())
                .clientConfig(clientConfig)
                .build();
        return new StandaloneRedisOps(client);
    }

    private static RedisOps createCluster(RedisTestConfig config, JedisClientConfig clientConfig) {
        Set<HostAndPort> nodes = mapNodes(config.getClusterNodes());
        RedisClusterClient client = RedisClusterClient.builder()
                .nodes(nodes)
                .clientConfig(clientConfig)
                .maxAttempts(config.getMaxAttempts())
                .build();
        return new ClusterRedisOps(client);
    }

    private static RedisOps createSentinel(RedisTestConfig config, JedisClientConfig clientConfig) {
        Set<HostAndPort> sentinels = mapNodes(config.getSentinelNodes());
        RedisSentinelClient client = RedisSentinelClient.builder()
                .masterName(config.getSentinelMasterName())
                .sentinels(sentinels)
                .clientConfig(clientConfig)
                .sentinelClientConfig(clientConfig)
                .build();
        return new SentinelRedisOps(client);
    }

    private static Set<HostAndPort> mapNodes(Iterable<RedisNode> nodes) {
        return java.util.stream.StreamSupport.stream(nodes.spliterator(), false)
                .map(node -> new HostAndPort(node.getHost(), node.getPort()))
                .collect(Collectors.toSet());
    }
}
