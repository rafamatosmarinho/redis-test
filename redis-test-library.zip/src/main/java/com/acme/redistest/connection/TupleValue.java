package com.acme.redistest.connection;

public record TupleValue(String value, double score) {
}
