package com.acme.redistest.connection;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface RedisOps extends AutoCloseable {
    String get(String key);
    String set(String key, String value);

    String hget(String key, String field);
    Map<String, String> hgetAll(String key);
    Long hset(String key, String field, String value);
    Long hset(String key, Map<String, String> hash);

    Long del(String key);
    String type(String key);
    Long ttl(String key);
    Set<String> keys(String pattern);
    List<String> lrange(String key, long start, long stop);
    Set<String> smembers(String key);
    List<TupleValue> zrangeWithScores(String key, long start, long stop);

    String jsonGet(String key);
    void jsonSet(String key, String json);

    @Override
    void close();
}
