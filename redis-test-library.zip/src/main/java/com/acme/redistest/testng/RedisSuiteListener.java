package com.acme.redistest.testng;

import com.acme.redistest.config.RedisTestConfig;
import com.acme.redistest.core.RedisTestClient;
import org.testng.ISuite;
import org.testng.ISuiteListener;

public class RedisSuiteListener implements ISuiteListener {

    @Override
    public void onStart(ISuite suite) {
        String mode = suite.getParameter("redis.mode");
        if (mode == null) {
            return;
        }

        RedisTestConfig.Builder builder = switch (mode.toUpperCase()) {
            case "STANDALONE" -> RedisTestConfig.standalone()
                    .host(suite.getParameter("redis.host"))
                    .port(Integer.parseInt(suite.getParameter("redis.port")));
            case "CLUSTER" -> {
                RedisTestConfig.Builder cluster = RedisTestConfig.cluster();
                String[] nodes = suite.getParameter("redis.cluster.nodes").split(",");
                for (String node : nodes) {
                    String[] pieces = node.trim().split(":");
                    cluster.addClusterNode(pieces[0], Integer.parseInt(pieces[1]));
                }
                yield cluster;
            }
            case "SENTINEL" -> {
                RedisTestConfig.Builder sentinel = RedisTestConfig.sentinel()
                        .sentinelMasterName(suite.getParameter("redis.sentinel.masterName"));
                String[] sentinels = suite.getParameter("redis.sentinel.nodes").split(",");
                for (String node : sentinels) {
                    String[] pieces = node.trim().split(":");
                    sentinel.addSentinelNode(pieces[0], Integer.parseInt(pieces[1]));
                }
                yield sentinel;
            }
            default -> throw new IllegalArgumentException("Unsupported redis.mode: " + mode);
        };

        String username = suite.getParameter("redis.username");
        String password = suite.getParameter("redis.password");
        if (username != null) builder.username(username);
        if (password != null) builder.password(password);

        RedisTestContext.set(RedisTestClient.create(builder.build()));
    }

    @Override
    public void onFinish(ISuite suite) {
        RedisTestContext.clear();
    }
}
