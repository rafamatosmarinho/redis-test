package com.acme.redistest.testng;

import com.acme.redistest.core.RedisTestClient;

public final class RedisTestContext {

    private static final ThreadLocal<RedisTestClient> CONTEXT = new ThreadLocal<>();

    private RedisTestContext() {
    }

    public static void set(RedisTestClient client) {
        CONTEXT.set(client);
    }

    public static RedisTestClient get() {
        return CONTEXT.get();
    }

    public static void clear() {
        RedisTestClient client = CONTEXT.get();
        if (client != null) {
            client.close();
        }
        CONTEXT.remove();
    }
}
