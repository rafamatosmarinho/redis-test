package com.acme.redistest.exception;

public class BucketNotFoundException extends RedisTestException {
    public BucketNotFoundException(String key) {
        super("Bucket/key not found: " + key);
    }
}
