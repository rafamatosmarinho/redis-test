package com.acme.redistest.exception;

public class UnsupportedBucketStructureException extends RedisTestException {
    public UnsupportedBucketStructureException(String message) {
        super(message);
    }
}
