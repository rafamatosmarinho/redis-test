package com.acme.redistest.exception;

public class RedisTestException extends RuntimeException {
    public RedisTestException(String message) {
        super(message);
    }

    public RedisTestException(String message, Throwable cause) {
        super(message, cause);
    }
}
