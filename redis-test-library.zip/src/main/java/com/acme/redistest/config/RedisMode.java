package com.acme.redistest.config;

public enum RedisMode {
    STANDALONE,
    CLUSTER,
    SENTINEL
}
