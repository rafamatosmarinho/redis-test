package com.acme.redistest.config;

import java.util.Objects;

public class RedisNode {
    private final String host;
    private final int port;

    public RedisNode(String host, int port) {
        this.host = Objects.requireNonNull(host, "host");
        this.port = port;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    @Override
    public String toString() {
        return host + ":" + port;
    }
}
