package com.acme.redistest.config;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class RedisTestConfig {

    private final RedisMode mode;
    private final String host;
    private final Integer port;
    private final String username;
    private final String password;
    private final Integer database;
    private final boolean ssl;
    private final Duration timeout;
    private final Duration socketTimeout;
    private final Integer maxAttempts;
    private final String sentinelMasterName;
    private final List<RedisNode> clusterNodes;
    private final List<RedisNode> sentinelNodes;

    private RedisTestConfig(Builder builder) {
        this.mode = builder.mode;
        this.host = builder.host;
        this.port = builder.port;
        this.username = builder.username;
        this.password = builder.password;
        this.database = builder.database;
        this.ssl = builder.ssl;
        this.timeout = builder.timeout;
        this.socketTimeout = builder.socketTimeout;
        this.maxAttempts = builder.maxAttempts;
        this.sentinelMasterName = builder.sentinelMasterName;
        this.clusterNodes = Collections.unmodifiableList(new ArrayList<>(builder.clusterNodes));
        this.sentinelNodes = Collections.unmodifiableList(new ArrayList<>(builder.sentinelNodes));
        validate();
    }

    private void validate() {
        Objects.requireNonNull(mode, "mode");

        switch (mode) {
            case STANDALONE -> {
                Objects.requireNonNull(host, "host is required for standalone");
                Objects.requireNonNull(port, "port is required for standalone");
            }
            case CLUSTER -> {
                if (clusterNodes.isEmpty()) {
                    throw new IllegalArgumentException("clusterNodes is required for cluster mode");
                }
            }
            case SENTINEL -> {
                if (sentinelNodes.isEmpty()) {
                    throw new IllegalArgumentException("sentinelNodes is required for sentinel mode");
                }
                Objects.requireNonNull(sentinelMasterName, "sentinelMasterName is required for sentinel mode");
            }
            default -> throw new IllegalStateException("Unsupported mode: " + mode);
        }
    }

    public RedisMode getMode() { return mode; }
    public String getHost() { return host; }
    public Integer getPort() { return port; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public Integer getDatabase() { return database; }
    public boolean isSsl() { return ssl; }
    public Duration getTimeout() { return timeout; }
    public Duration getSocketTimeout() { return socketTimeout; }
    public Integer getMaxAttempts() { return maxAttempts; }
    public String getSentinelMasterName() { return sentinelMasterName; }
    public List<RedisNode> getClusterNodes() { return clusterNodes; }
    public List<RedisNode> getSentinelNodes() { return sentinelNodes; }

    public static Builder standalone() {
        return new Builder().mode(RedisMode.STANDALONE);
    }

    public static Builder cluster() {
        return new Builder().mode(RedisMode.CLUSTER);
    }

    public static Builder sentinel() {
        return new Builder().mode(RedisMode.SENTINEL);
    }

    public static class Builder {
        private RedisMode mode;
        private String host;
        private Integer port;
        private String username;
        private String password;
        private Integer database = 0;
        private boolean ssl = false;
        private Duration timeout = Duration.ofSeconds(2);
        private Duration socketTimeout = Duration.ofSeconds(2);
        private Integer maxAttempts = 5;
        private String sentinelMasterName;
        private final List<RedisNode> clusterNodes = new ArrayList<>();
        private final List<RedisNode> sentinelNodes = new ArrayList<>();

        public Builder mode(RedisMode mode) { this.mode = mode; return this; }
        public Builder host(String host) { this.host = host; return this; }
        public Builder port(int port) { this.port = port; return this; }
        public Builder username(String username) { this.username = username; return this; }
        public Builder password(String password) { this.password = password; return this; }
        public Builder database(int database) { this.database = database; return this; }
        public Builder ssl(boolean ssl) { this.ssl = ssl; return this; }
        public Builder timeout(Duration timeout) { this.timeout = timeout; return this; }
        public Builder socketTimeout(Duration socketTimeout) { this.socketTimeout = socketTimeout; return this; }
        public Builder maxAttempts(int maxAttempts) { this.maxAttempts = maxAttempts; return this; }
        public Builder sentinelMasterName(String sentinelMasterName) { this.sentinelMasterName = sentinelMasterName; return this; }
        public Builder addClusterNode(String host, int port) { this.clusterNodes.add(new RedisNode(host, port)); return this; }
        public Builder addSentinelNode(String host, int port) { this.sentinelNodes.add(new RedisNode(host, port)); return this; }

        public RedisTestConfig build() { return new RedisTestConfig(this); }
    }
}
