package com.acme.redistest.core;

import java.time.Duration;
import java.util.function.Predicate;
import java.util.function.Supplier;

public final class RedisAwait {

    private RedisAwait() {
    }

    public static <T> T until(Supplier<T> supplier, Predicate<T> condition, Duration timeout, Duration interval) {
        long deadline = System.nanoTime() + timeout.toNanos();
        T current = supplier.get();

        while (!condition.test(current)) {
            if (System.nanoTime() >= deadline) {
                return current;
            }
            try {
                Thread.sleep(interval.toMillis());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Interrupted while waiting Redis state", e);
            }
            current = supplier.get();
        }

        return current;
    }
}
