package com.acme.redistest.core;

import com.acme.redistest.bucket.BucketFacade;
import com.acme.redistest.config.RedisTestConfig;
import com.acme.redistest.connection.RedisConnectionFactory;
import com.acme.redistest.connection.RedisOps;

public class RedisTestClient implements AutoCloseable {

    private final RedisOps redisOps;
    private final RedisResetService resetService;
    private final RedisKeyOps keyOps;

    private RedisTestClient(RedisOps redisOps) {
        this.redisOps = redisOps;
        this.resetService = new RedisResetService(redisOps);
        this.keyOps = new RedisKeyOps(redisOps);
    }

    public static RedisTestClient create(RedisTestConfig config) {
        return new RedisTestClient(RedisConnectionFactory.create(config));
    }

    public BucketFacade bucket(String key) {
        return new BucketFacade(redisOps, key);
    }

    public RedisResetService reset() {
        return resetService;
    }

    public RedisKeyOps keys() {
        return keyOps;
    }

    @Override
    public void close() {
        redisOps.close();
    }
}
