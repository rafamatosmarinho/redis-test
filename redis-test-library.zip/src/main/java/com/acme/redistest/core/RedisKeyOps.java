package com.acme.redistest.core;

import com.acme.redistest.connection.RedisOps;

import java.util.Set;

public class RedisKeyOps {

    private final RedisOps redisOps;

    public RedisKeyOps(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    public String type(String key) {
        return redisOps.type(key);
    }

    public Long ttl(String key) {
        return redisOps.ttl(key);
    }

    public Set<String> keys(String pattern) {
        return redisOps.keys(pattern);
    }

    public boolean exists(String key) {
        return redisOps.type(key) != null && !"none".equalsIgnoreCase(redisOps.type(key));
    }
}
