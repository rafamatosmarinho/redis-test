package com.acme.redistest.core;

import com.acme.redistest.connection.RedisOps;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import java.util.Map;
import java.util.Set;

public class RedisResetService {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final RedisOps redisOps;

    public RedisResetService(RedisOps redisOps) {
        this.redisOps = redisOps;
    }

    public void setString(String key, String value) {
        redisOps.set(key, value);
    }

    public void setHashField(String key, String field, String value) {
        redisOps.hset(key, field, value);
    }

    public void setHash(String key, Map<String, String> values) {
        redisOps.hset(key, values);
    }

    public void setJsonDocument(String key, String json) {
        redisOps.jsonSet(key, json);
    }

    public void setJsonPath(String key, String jsonPath, Object value) {
        String current = redisOps.jsonGet(key);
        String effective = current == null || current.isBlank() ? "{}" : current;
        DocumentContext ctx = JsonPath.parse(effective);
        ctx.set(jsonPath, value);
        redisOps.jsonSet(key, ctx.jsonString());
    }

    public void deleteKey(String key) {
        redisOps.del(key);
    }

    public void deleteByPattern(String pattern) {
        Set<String> keys = redisOps.keys(pattern);
        for (String key : keys) {
            redisOps.del(key);
        }
    }

    public void resetFromJson(String key, String payload) {
        try {
            JsonNode jsonNode = MAPPER.readTree(payload);
            if (jsonNode.isObject()) {
                redisOps.jsonSet(key, payload);
            } else {
                redisOps.set(key, payload);
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Unable to parse payload for reset", e);
        }
    }
}
