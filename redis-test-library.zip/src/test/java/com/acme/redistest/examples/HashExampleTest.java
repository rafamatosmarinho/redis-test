package com.acme.redistest.examples;

import com.acme.redistest.bucket.BucketStructure;
import com.acme.redistest.bucket.model.BucketConsumptionResult;
import com.acme.redistest.config.RedisTestConfig;
import com.acme.redistest.core.RedisTestClient;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HashExampleTest {

    private RedisTestClient redis;

    @BeforeClass
    public void setup() {
        redis = RedisTestClient.create(
                RedisTestConfig.standalone()
                        .host("localhost")
                        .port(6379)
                        .build()
        );

        redis.reset().setHashField("bucket:client-123", "tokens", "10");
    }

    @AfterClass
    public void tearDown() {
        redis.close();
    }

    @Test
    public void shouldValidateHashFieldConsumption() {
        BucketConsumptionResult result = redis.bucket("bucket:client-123")
                .using(BucketStructure.HASH)
                .field("tokens")
                .verifyConsumption(1, () -> redis.reset().setHashField("bucket:client-123", "tokens", "9"));

        result.assertConsumedExactly(1);
    }
}
