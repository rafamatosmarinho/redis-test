package com.acme.redistest.examples;

import com.acme.redistest.bucket.BucketStructure;
import com.acme.redistest.bucket.model.BucketConsumptionResult;
import com.acme.redistest.config.RedisTestConfig;
import com.acme.redistest.core.RedisTestClient;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class JsonBucketExampleTest {

    private RedisTestClient redis;

    @BeforeClass
    public void setup() {
        redis = RedisTestClient.create(
                RedisTestConfig.standalone()
                        .host("localhost")
                        .port(6379)
                        .build()
        );

        redis.reset().setJsonDocument("bucket:json:client-123", """
                {
                  "tokens": 10,
                  "windowSeconds": 60,
                  "metadata": {
                    "type": "token-bucket"
                  }
                }
                """);
    }

    @AfterClass
    public void tearDown() {
        redis.close();
    }

    @Test
    public void shouldValidateJsonPathConsumption() {
        BucketConsumptionResult result = redis.bucket("bucket:json:client-123")
                .using(BucketStructure.JSON)
                .jsonPath("$.tokens")
                .verifyConsumption(1, () -> redis.reset().setJsonDocument("bucket:json:client-123", """
                        {
                          "tokens": 9,
                          "windowSeconds": 60,
                          "metadata": {
                            "type": "token-bucket"
                          }
                        }
                        """));

        result.assertConsumedExactly(1);
    }
}
