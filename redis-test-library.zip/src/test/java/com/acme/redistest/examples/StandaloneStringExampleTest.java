package com.acme.redistest.examples;

import com.acme.redistest.bucket.BucketStructure;
import com.acme.redistest.bucket.model.BucketConsumptionResult;
import com.acme.redistest.config.RedisTestConfig;
import com.acme.redistest.core.RedisTestClient;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class StandaloneStringExampleTest {

    private RedisTestClient redis;

    @BeforeClass
    public void setup() {
        redis = RedisTestClient.create(
                RedisTestConfig.standalone()
                        .host("localhost")
                        .port(6379)
                        .database(0)
                        .build()
        );

        redis.reset().setString("rate-limit:token:client-01", "10");
    }

    @AfterClass
    public void tearDown() {
        redis.close();
    }

    @Test
    public void shouldConsumeOneToken() {
        BucketConsumptionResult result = redis.bucket("rate-limit:token:client-01")
                .using(BucketStructure.STRING)
                .verifyConsumption(1, () -> redis.reset().setString("rate-limit:token:client-01", "9"));

        result.assertConsumedExactly(1);
    }
}
