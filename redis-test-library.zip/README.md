# redis-test

Biblioteca Java para testes automatizados que precisam **ler, resetar, comparar e validar consumo de buckets em Redis** com suporte a:

- Redis **standalone**
- Redis **cluster**
- Redis **sentinel**
- buckets em **STRING**, **HASH**, **LIST**, **SET**, **ZSET** e **JSON**
- polling para cenários assíncronos
- integração simples com **TestNG**

> Foco: automação de API, integração e contratos de comportamento que dependem de rate limit, token bucket, quota bucket, contadores e estruturas distribuídas em Redis.

---

## Motivação

Em muitos projetos de automação, o teste precisa:

- preparar o estado do Redis antes do cenário
- ler o valor atual do bucket
- executar uma chamada HTTP ou fluxo de negócio
- verificar se **uma ficha foi consumida**
- resetar dados ao final ou entre execuções
- funcionar em ambientes com standalone, cluster ou sentinel

A ideia desta biblioteca é centralizar isso em uma API reutilizável, sem espalhar detalhes de Jedis pelos testes.

---

## Stack base

A implementação desta versão foi desenhada em cima do **Jedis 7.x**, alinhada com a documentação e APIs mais recentes do cliente Java. Desde o Jedis 7.2.0, a documentação oficial passou a destacar as novas classes de conexão `RedisClient`, `RedisClusterClient` e `RedisSentinelClient`, substituindo as classes antigas para standalone, cluster e sentinel. Também há documentação oficial mostrando suporte a RedisJSON via Jedis. citeturn550604view0turn550604view2turn550604view1turn503590search5turn174881search1

---

## Estrutura do projeto

```text
redis-test
 ├── pom.xml
 ├── README.md
 └── src
     ├── main
     │   └── java
     │       └── com.acme.redistest
     │           ├── bucket
     │           ├── config
     │           ├── connection
     │           ├── core
     │           ├── exception
     │           └── testng
     └── test
         └── java
             └── com.acme.redistest.examples
```

---

## Principais conceitos

### 1. `RedisTestConfig`
Define modo de conexão e parâmetros do ambiente:

- `STANDALONE`
- `CLUSTER`
- `SENTINEL`

### 2. `RedisConnectionFactory`
Cria a conexão adequada e devolve um `RedisOps`, que é a abstração usada pelo resto da biblioteca.

### 3. `RedisTestClient`
Facade principal para consumo da lib:

- `bucket(key)` para leitura/validação
- `reset()` para setup/reset de estado
- `keys()` para operações gerais de chave

### 4. `BucketFacade`
API fluente para ler bucket e validar consumo:

- `using(BucketStructure.STRING)`
- `field("tokens")`
- `jsonPath("$.tokens")`
- `verifyConsumption(1, action)`

### 5. `RedisResetService`
Centraliza criação e reset de dados:

- `setString`
- `setHashField`
- `setHash`
- `setJsonDocument`
- `setJsonPath`
- `deleteKey`
- `deleteByPattern`

---

## Dependência Maven no projeto consumidor

```xml
<dependency>
    <groupId>com.acme.testing</groupId>
    <artifactId>redis-test</artifactId>
    <version>2.0.0</version>
</dependency>
```

---

## Dependências da própria lib

A biblioteca usa:

- `jedis`
- `jackson-databind`
- `json-path`
- `testng`
- `slf4j`

A documentação oficial do Jedis mostra instalação via Maven e a linha 7.x como API atual para Java, além de exemplos de conexão standalone, cluster e TLS. citeturn550604view0turn550604view2turn503590search5

---

## Configuração por cenário

## 1) Standalone

```java
RedisTestClient redis = RedisTestClient.create(
        RedisTestConfig.standalone()
                .host("localhost")
                .port(6379)
                .database(0)
                .build()
);
```

## 2) Cluster

```java
RedisTestClient redis = RedisTestClient.create(
        RedisTestConfig.cluster()
                .addClusterNode("127.0.0.1", 7000)
                .addClusterNode("127.0.0.1", 7001)
                .addClusterNode("127.0.0.1", 7002)
                .username("default")
                .password("secret")
                .maxAttempts(10)
                .build()
);
```

A documentação oficial do Jedis mostra `RedisClusterClient` com builder baseado em seed nodes, e o Redis documenta que em cluster padrões de chave com hash tag ajudam operações focadas em um slot específico. Isso é especialmente relevante para limpeza por padrão e para projetos que querem operar com chaves como `{tenant-a}:bucket:client-123`. citeturn550604view2turn835594search1turn955090search12

## 3) Sentinel

```java
RedisTestClient redis = RedisTestClient.create(
        RedisTestConfig.sentinel()
                .sentinelMasterName("mymaster")
                .addSentinelNode("127.0.0.1", 26379)
                .addSentinelNode("127.0.0.1", 26380)
                .addSentinelNode("127.0.0.1", 26381)
                .username("default")
                .password("secret")
                .build()
);
```

A API nova do Jedis expõe `RedisSentinelClient.builder()` com métodos de builder para `masterName`, `sentinels` e `sentinelClientConfig`, e a especificação de Sentinel do Redis reforça que clientes precisam suportar descoberta do master e failover automático. citeturn174881search1turn174881search5turn503590search0turn503590search2

---

## Estruturas suportadas

## STRING

Exemplo de valor simples:

```text
rate-limit:token:client-01 = "10"
```

Leitura:

```java
Long available = redis.bucket("rate-limit:token:client-01")
        .using(BucketStructure.STRING)
        .read()
        .getValue()
        .getNumericValue();
```

## HASH

Exemplo:

```text
bucket:client-123 -> { tokens=10, refillRate=1 }
```

Leitura de campo:

```java
Long tokens = redis.bucket("bucket:client-123")
        .using(BucketStructure.HASH)
        .field("tokens")
        .read()
        .getValue()
        .getNumericValue();
```

## LIST

Exemplo:

```java
BucketState state = redis.bucket("queue:orders")
        .using(BucketStructure.LIST)
        .read();
```

## SET

```java
BucketState state = redis.bucket("clients:online")
        .using(BucketStructure.SET)
        .read();
```

## ZSET

```java
BucketState state = redis.bucket("bucket:history")
        .using(BucketStructure.ZSET)
        .read();
```

## JSON

O Redis documenta os comandos `JSON.SET` e `JSON.GET`, e o próprio repositório do Jedis mostra suporte a RedisJSON usando `RedisClient` ou `RedisClusterClient`. citeturn955090search10turn955090search1turn550604view1

Exemplo de documento:

```json
{
  "tokens": 10,
  "windowSeconds": 60,
  "metadata": {
    "type": "token-bucket"
  }
}
```

Leitura do documento inteiro:

```java
String json = redis.bucket("bucket:json:client-123")
        .using(BucketStructure.JSON)
        .read()
        .getValue()
        .getJsonValue();
```

Leitura via JsonPath:

```java
Long tokens = redis.bucket("bucket:json:client-123")
        .using(BucketStructure.JSON)
        .jsonPath("$.tokens")
        .read()
        .getValue()
        .getNumericValue();
```

---

## Exemplos de reset

## Reset de string

```java
redis.reset().setString("rate-limit:token:client-01", "10");
```

## Reset de hash field

```java
redis.reset().setHashField("bucket:client-123", "tokens", "10");
```

## Reset de hash completo

```java
redis.reset().setHash("bucket:client-123", Map.of(
        "tokens", "10",
        "refillRate", "1"
));
```

## Reset de documento JSON completo

```java
redis.reset().setJsonDocument("bucket:json:client-123", """
        {
          "tokens": 10,
          "windowSeconds": 60,
          "metadata": {
            "type": "token-bucket"
          }
        }
        """);
```

## Reset por JsonPath

```java
redis.reset().setJsonPath("bucket:json:client-123", "$.tokens", 10);
```

## Remoção de chave

```java
redis.reset().deleteKey("bucket:client-123");
```

## Remoção por padrão

```java
redis.reset().deleteByPattern("test:*");
```

> Observação importante para cluster: `KEYS` e limpezas por padrão merecem cuidado. O Redis documenta que, em cluster, padrões com **hash tag** podem ficar restritos a um slot específico e reduzir varredura. Para suites grandes, prefira chaves namespaced como `{suite-a}:bucket:*`. citeturn955090search12

---

## Validação de consumo em diferentes cenários

## 1) STRING bucket

```java
BucketConsumptionResult result = redis.bucket("rate-limit:token:client-01")
        .using(BucketStructure.STRING)
        .verifyConsumption(1, () -> {
            authApiClient.generateToken();
        });

result.assertConsumedExactly(1);
```

## 2) HASH bucket

```java
BucketConsumptionResult result = redis.bucket("bucket:client-123")
        .using(BucketStructure.HASH)
        .field("tokens")
        .verifyConsumption(1, () -> {
            authApiClient.generateToken();
        });

result.assertConsumedExactly(1);
```

## 3) JSON bucket

```java
BucketConsumptionResult result = redis.bucket("bucket:json:client-123")
        .using(BucketStructure.JSON)
        .jsonPath("$.tokens")
        .verifyConsumption(1, () -> {
            authApiClient.generateToken();
        });

result.assertConsumedExactly(1);
```

---

## Polling e cenários assíncronos

Quando a baixa no Redis não é imediata:

```java
BucketConsumptionResult result = redis.bucket("bucket:client-123")
        .using(BucketStructure.HASH)
        .field("tokens")
        .await(Duration.ofSeconds(5), Duration.ofMillis(200))
        .verifyConsumption(1, () -> {
            authApiClient.generateToken();
        });
```

---

## Exemplo completo com RestAssured + TestNG

```java
public class AccessTokenBucketTest {

    private RedisTestClient redis;
    private AuthApiClient authApiClient;

    @BeforeClass
    public void setup() {
        redis = RedisTestClient.create(
                RedisTestConfig.standalone()
                        .host("localhost")
                        .port(6379)
                        .build()
        );

        authApiClient = new AuthApiClient("http://localhost:8080", "/oauth/token");

        redis.reset().setHashField("bucket:client-123", "tokens", "10");
    }

    @AfterClass
    public void tearDown() {
        redis.close();
    }

    @Test
    public void shouldConsumeOneTokenWhenGeneratingAccessToken() {
        BucketConsumptionResult result = redis.bucket("bucket:client-123")
                .using(BucketStructure.HASH)
                .field("tokens")
                .verifyConsumption(1, () -> {
                    authApiClient.generateToken("client-123", "secret-123");
                });

        result.assertConsumedExactly(1);
    }
}
```

---

## Exemplo com TestNG listener

A biblioteca traz um `RedisSuiteListener` para inicialização por parâmetros do `testng.xml`.

### `testng.xml`

```xml
<suite name="Redis Suite">
    <listeners>
        <listener class-name="com.acme.redistest.testng.RedisSuiteListener"/>
    </listeners>

    <parameter name="redis.mode" value="STANDALONE"/>
    <parameter name="redis.host" value="localhost"/>
    <parameter name="redis.port" value="6379"/>

    <test name="API Tests">
        <classes>
            <class name="com.acme.tests.AccessTokenBucketTest"/>
        </classes>
    </test>
</suite>
```

Uso no teste:

```java
RedisTestClient redis = RedisTestContext.get();
```

---

## Recomendações de modelagem de chave

### Para standalone
Pode usar chave simples sem grande preocupação de slot.

### Para cluster
Prefira hash tag para agrupar chaves relacionadas:

```text
{suite-a}:bucket:client-123
{suite-a}:bucket:client-456
{suite-a}:history:client-123
```

Isso ajuda em cenários de limpeza por padrão, reset por suíte e consistência operacional em cluster. O Redis documenta explicitamente o comportamento de padrões e slots quando há hash tags. citeturn955090search12

### Para sentinel
Modele a chave normalmente; a preocupação principal fica na descoberta do master e failover, que é tratada pelo client sentinel.

---

## Limitações conscientes desta versão

- `deleteByPattern` em cluster ainda depende da semântica de `KEYS`; em ambientes grandes, vale evoluir para scan por nó.
- `JSON` foi modelado com reset de documento completo e leitura parcial via `JsonPath`; para cenários muito pesados, pode valer expor comandos path-based nativos da API JSON do Jedis.
- Integração pronta com TestNG; JUnit 5 pode ser adicionada em versão futura.

---

## Roadmap sugerido

### v2.1
- `SCAN` distribuído por nó para cluster
- TTL reset
- snapshot/diff de estado

### v2.2
- JUnit 5 extension
- assertions reutilizáveis para estruturas complexas
- suporte a comparação estrutural de JSON

### v3
- namespaces automáticos por suíte
- relatórios detalhados de before/after
- builders de massa de dados para buckets

---

## Arquivos principais desta entrega

- `pom.xml`
- código-fonte da biblioteca
- exemplos de testes
- este `README.md`

---

## Observações finais de compatibilidade

A documentação oficial do Redis recomenda o uso de TLS em produção e mostra configuração explícita do `DefaultJedisClientConfig` para SSL, autenticação e timeouts. O guia de produção do Jedis também enfatiza boas práticas de confiabilidade e operação em ambientes reais. Para ambientes de CI/CD, vale parametrizar credenciais, SSL e timeouts por variável de ambiente. citeturn550604view2turn955090search7
